import React, { useState } from 'react';

const SchedulerControl = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const triggerDailyJob = async () => {
    setIsLoading(true);
    setMessage('');
    setError('');

    try {
      const response = await fetch('/api/campaigns/scheduler/trigger-daily-job', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session-id': 'test-session' // Remplacez par votre vraie session
        }
      });

      const data = await response.json();

      if (response.ok) {
        setMessage(`✅ ${data.message}`);
      } else {
        setError(`❌ ${data.error}: ${data.details}`);
      }
    } catch (err) {
      setError(`❌ Erreur de connexion: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">
        🕐 Contrôle du Scheduler
      </h2>
      
      <div className="space-y-4">
        <div className="bg-blue-50 p-4 rounded-lg">
          <h3 className="font-semibold text-blue-800 mb-2">
            Job Daily + WHOIS + Million Verifier
          </h3>
          <p className="text-blue-700 text-sm">
            Déclenche manuellement le processus complet : téléchargement du fichier de la veille, 
            traitement WHOIS, puis Million Verifier.
          </p>
        </div>

        <button
          onClick={triggerDailyJob}
          disabled={isLoading}
          className={`w-full py-3 px-4 rounded-lg font-semibold transition-colors ${
            isLoading
              ? 'bg-gray-400 cursor-not-allowed'
              : 'bg-green-600 hover:bg-green-700 text-white'
          }`}
        >
          {isLoading ? '🔄 Traitement en cours...' : '🚀 Déclencher le Job'}
        </button>

        {message && (
          <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg">
            {message}
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">
            {error}
          </div>
        )}

        <div className="text-xs text-gray-600 text-center">
          ⏰ Ce job est normalement programmé pour s'exécuter automatiquement à 6h00 du matin
        </div>
      </div>
    </div>
  );
};

export default SchedulerControl;
