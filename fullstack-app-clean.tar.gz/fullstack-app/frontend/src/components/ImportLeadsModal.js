import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ImportLeadsModal = ({ isOpen, onClose, campaignId, onImportComplete }) => {
  const [csvFiles, setCsvFiles] = useState([]);
  const [selectedFile, setSelectedFile] = useState('');
  const [batchSize, setBatchSize] = useState(100);
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (isOpen) {
      loadCsvFiles();
    }
  }, [isOpen]);

  const loadCsvFiles = async () => {
    try {
      const response = await axios.get('/api/campaigns/smartlead/csv-files');
      if (response.data.success) {
        setCsvFiles(response.data.files);
      }
    } catch (error) {
      console.error('Erreur lors du chargement des fichiers CSV:', error);
      setError('Impossible de charger la liste des fichiers CSV');
    }
  };

  const handleImport = async () => {
    if (!selectedFile) {
      setError('Veuillez sélectionner un fichier CSV');
      return;
    }

    setIsImporting(true);
    setError(null);
    setImportProgress({ status: 'starting', message: 'Démarrage de l\'import...' });

    try {
      const response = await axios.post(`/api/campaigns/${campaignId}/import-leads`, {
        csvFile: selectedFile,
        batchSize: parseInt(batchSize)
      });

      if (response.data.success) {
        setImportProgress({
          status: 'completed',
          message: `Import terminé avec succès ! ${response.data.result.success}/${response.data.result.total} leads importés.`
        });
        
        // Notifier le composant parent
        if (onImportComplete) {
          onImportComplete(response.data.result);
        }
        
        // Fermer automatiquement après 3 secondes
        setTimeout(() => {
          onClose();
        }, 3000);
      }
    } catch (error) {
      console.error('Erreur lors de l\'import:', error);
      setError(error.response?.data?.error || 'Erreur lors de l\'import');
      setImportProgress({ status: 'error', message: 'Import échoué' });
    } finally {
      setIsImporting(false);
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Importer des leads</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 text-2xl font-bold"
          >
            ×
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
            {error}
          </div>
        )}

        {importProgress && (
          <div className={`mb-4 p-3 rounded ${
            importProgress.status === 'completed' ? 'bg-green-100 border border-green-400 text-green-700' :
            importProgress.status === 'error' ? 'bg-red-100 border border-red-400 text-red-700' :
            'bg-blue-100 border border-blue-400 text-blue-700'
          }`}>
            {importProgress.message}
          </div>
        )}

        <div className="space-y-4">
          {/* Sélection du fichier CSV */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Fichier CSV à importer
            </label>
            <select
              value={selectedFile}
              onChange={(e) => setSelectedFile(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              disabled={isImporting}
            >
              <option value="">Sélectionner un fichier...</option>
              {csvFiles.map((file) => (
                <option key={file.name} value={file.path}>
                  {file.name} ({formatFileSize(file.size)}) - {formatDate(file.modified)}
                </option>
              ))}
            </select>
          </div>

          {/* Taille des lots */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Taille des lots (max 100)
            </label>
            <input
              type="number"
              min="1"
              max="100"
              value={batchSize}
              onChange={(e) => setBatchSize(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              disabled={isImporting}
            />
            <p className="text-sm text-gray-500 mt-1">
              Nombre de leads traités par lot. Plus le lot est petit, plus l'import est fiable.
            </p>
          </div>

          {/* Informations sur le fichier sélectionné */}
          {selectedFile && (
            <div className="p-3 bg-gray-50 rounded-md">
              <h4 className="font-medium text-gray-700 mb-2">Informations sur le fichier</h4>
              {(() => {
                const file = csvFiles.find(f => f.path === selectedFile);
                if (file) {
                  return (
                    <div className="text-sm text-gray-600 space-y-1">
                      <p><strong>Nom:</strong> {file.name}</p>
                      <p><strong>Taille:</strong> {formatFileSize(file.size)}</p>
                      <p><strong>Modifié le:</strong> {formatDate(file.modified)}</p>
                    </div>
                  );
                }
                return null;
              })()}
            </div>
          )}

          {/* Boutons d'action */}
          <div className="flex justify-end space-x-3 pt-4">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300 transition-colors"
              disabled={isImporting}
            >
              Annuler
            </button>
            <button
              onClick={handleImport}
              disabled={!selectedFile || isImporting}
              className={`px-6 py-2 text-white rounded-md transition-colors ${
                !selectedFile || isImporting
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              {isImporting ? (
                <span className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Import en cours...
                </span>
              ) : (
                'Importer les leads'
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImportLeadsModal;
