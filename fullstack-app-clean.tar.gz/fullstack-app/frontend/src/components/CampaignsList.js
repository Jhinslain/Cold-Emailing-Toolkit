import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ImportLeadsModal from './ImportLeadsModal';

const CampaignsList = () => {
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [importModalOpen, setImportModalOpen] = useState(false);
  const [selectedCampaignForImport, setSelectedCampaignForImport] = useState(null);

  useEffect(() => {
    fetchCampaigns();
  }, []);

  const fetchCampaigns = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/campaigns');
      setCampaigns(response.data);
      setError(null);
    } catch (error) {
      console.error('Erreur lors de la récupération des campagnes:', error);
      setError('Impossible de charger les campagnes');
    } finally {
      setLoading(false);
    }
  };

  const handleImportLeads = (campaign) => {
    setSelectedCampaignForImport(campaign);
    setImportModalOpen(true);
  };

  const handleImportComplete = (result) => {
    // Rafraîchir la liste des campagnes
    fetchCampaigns();
    
    // Afficher une notification de succès
    console.log('Import terminé:', result);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'DRAFTED':
        return 'bg-gray-100 text-gray-800';
      case 'ACTIVE':
        return 'bg-green-100 text-green-800';
      case 'PAUSED':
        return 'bg-yellow-100 text-yellow-800';
      case 'STOPPED':
        return 'bg-red-100 text-red-800';
      case 'COMPLETED':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'DRAFTED':
        return 'Brouillon';
      case 'ACTIVE':
        return 'Active';
      case 'PAUSED':
        return 'En pause';
      case 'STOPPED':
        return 'Arrêtée';
      case 'COMPLETED':
        return 'Terminée';
      default:
        return status;
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        {error}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Campagnes</h1>
        <button
          onClick={() => {/* Ajouter logique pour créer une campagne */}}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md"
        >
          + Nouvelle campagne
        </button>
      </div>

      {campaigns.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">Aucune campagne trouvée</p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {campaigns.map((campaign) => (
            <div key={campaign.id} className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
              {/* En-tête de la campagne */}
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">
                    {campaign.name}
                  </h3>
                  <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(campaign.status)}`}>
                    {getStatusLabel(campaign.status)}
                  </span>
                </div>
              </div>

              {/* Description */}
              {campaign.description && (
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                  {campaign.description}
                </p>
              )}

              {/* Statistiques */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-blue-600">{campaign.totalLeads || 0}</p>
                  <p className="text-xs text-gray-500">Total leads</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-green-600">{campaign.processedLeads || 0}</p>
                  <p className="text-xs text-gray-500">Traités</p>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-wrap gap-2">
                {/* Bouton d'import pour les campagnes DRAFTED */}
                {campaign.status === 'DRAFTED' && (
                  <button
                    onClick={() => handleImportLeads(campaign)}
                    className="bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-md text-sm flex items-center"
                  >
                    📥 Importer des leads
                  </button>
                )}

                {/* Autres boutons d'action selon le statut */}
                {campaign.status === 'DRAFTED' && (
                  <button className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-md text-sm">
                    ▶️ Démarrer
                  </button>
                )}

                {campaign.status === 'ACTIVE' && (
                  <>
                    <button className="bg-yellow-600 hover:bg-yellow-700 text-white px-3 py-2 rounded-md text-sm">
                      ⏸️ Pause
                    </button>
                    <button className="bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-md text-sm">
                      ⏹️ Arrêter
                    </button>
                  </>
                )}

                {campaign.status === 'PAUSED' && (
                  <button className="bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-md text-sm">
                    ▶️ Reprendre
                  </button>
                )}

                {/* Bouton d'édition pour toutes les campagnes */}
                <button className="bg-gray-600 hover:bg-gray-700 text-white px-3 py-2 rounded-md text-sm">
                  ✏️ Modifier
                </button>

                {/* Bouton de duplication */}
                <button className="bg-purple-600 hover:bg-purple-700 text-white px-3 py-2 rounded-md text-sm">
                  📋 Dupliquer
                </button>
              </div>

              {/* Informations supplémentaires */}
              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="flex justify-between text-xs text-gray-500">
                  <span>Créée le {new Date(campaign.createdAt).toLocaleDateString('fr-FR')}</span>
                  {campaign.smartLeadsId && (
                    <span>ID: {campaign.smartLeadsId}</span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal d'import */}
      {importModalOpen && selectedCampaignForImport && (
        <ImportLeadsModal
          isOpen={importModalOpen}
          onClose={() => {
            setImportModalOpen(false);
            setSelectedCampaignForImport(null);
          }}
          campaignId={selectedCampaignForImport.id}
          onImportComplete={handleImportComplete}
        />
      )}
    </div>
  );
};

export default CampaignsList;
