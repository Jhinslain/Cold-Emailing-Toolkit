const fs = require('fs');
const path = require('path');
const RegistryService = require('./registryService');

class StatisticsService {
    constructor() {
        this.dataDir = path.join(__dirname, '../data');
        this.registryService = new RegistryService(this.dataDir);
        console.log('📊 Service de statistiques initialisé');
    }

    /**
     * Récupère les statistiques existantes d'un fichier
     * @param {string} fileName - Nom du fichier
     * @returns {Object} Statistiques existantes
     */
    getExistingStats(fileName) {
        try {
            const registry = this.registryService.loadRegistry();
            return registry[fileName]?.statistiques || {};
        } catch (error) {
            console.warn(`⚠️ Erreur lors de la lecture des statistiques pour ${fileName}:`, error.message);
            return {};
        }
    }

    /**
     * Met à jour les statistiques d'un fichier en préservant les anciennes
     * @param {string} fileName - Nom du fichier
     * @param {Object} newStats - Nouvelles statistiques à ajouter
     * @param {Object} fileInfo - Informations générales du fichier
     */
    updateFileStats(fileName, newStats, fileInfo = {}) {
        try {
            const registry = this.registryService.loadRegistry();
            
            // Récupérer les statistiques existantes
            const existingStats = registry[fileName]?.statistiques || {};
            
            // Fusionner les statistiques (préserver l'existant + ajouter le nouveau)
            const mergedStats = {
                // Préserver toutes les statistiques existantes
                domain_lignes: existingStats.domain_lignes || 0,
                domain_temps: existingStats.domain_temps || 0,
                whois_lignes: existingStats.whois_lignes || 0,
                whois_temps: existingStats.whois_temps || 0,
                dedup_lignes: existingStats.dedup_lignes || 0,
                dedup_temps: existingStats.dedup_temps || 0,
                verifier_lignes: existingStats.verifier_lignes || 0,
                verifier_temps: existingStats.verifier_temps || 0,
                // Ajouter/mettre à jour les nouvelles statistiques
                ...newStats
            };

            // Créer ou mettre à jour l'entrée du fichier
            registry[fileName] = {
                ...registry[fileName], // Préserver les données existantes
                ...fileInfo, // Ajouter les nouvelles informations
                size: fileInfo.size || this.getFileSize(fileName),
                modified: fileInfo.modified || new Date().toISOString(),
                lastUpdated: new Date().toISOString(),
                statistiques: mergedStats
            };

            this.registryService.saveRegistry(registry);
            
            console.log(`📊 Statistiques mises à jour pour ${fileName}:`);
            console.log(`   - Domain: ${mergedStats.domain_lignes} lignes (${mergedStats.domain_temps}s)`);
            console.log(`   - WHOIS: ${mergedStats.whois_lignes} lignes (${mergedStats.whois_temps}s)`);
            console.log(`   - Déduplication: ${mergedStats.dedup_lignes} lignes (${mergedStats.dedup_temps}s)`);
            console.log(`   - Verifier: ${mergedStats.verifier_lignes} lignes (${mergedStats.verifier_temps}s)`);
            
            return mergedStats;
        } catch (error) {
            console.error(`❌ Erreur lors de la mise à jour des statistiques pour ${fileName}:`, error.message);
            throw error;
        }
    }

    /**
     * Transfère les statistiques d'un fichier source vers un fichier de destination
     * @param {string} sourceFileName - Nom du fichier source
     * @param {string} destFileName - Nom du fichier de destination
     * @param {Object} additionalStats - Statistiques supplémentaires à ajouter
     * @param {Object} fileInfo - Informations générales du fichier de destination
     */
    transferStats(sourceFileName, destFileName, additionalStats = {}, fileInfo = {}) {
        try {
            const registry = this.registryService.loadRegistry();
            
            // Récupérer les statistiques du fichier source
            const sourceStats = registry[sourceFileName]?.statistiques || {};
            
            // Fusionner avec les nouvelles statistiques
            const mergedStats = {
                // Préserver toutes les statistiques du fichier source
                domain_lignes: sourceStats.domain_lignes || 0,
                domain_temps: sourceStats.domain_temps || 0,
                whois_lignes: sourceStats.whois_lignes || 0,
                whois_temps: sourceStats.whois_temps || 0,
                dedup_lignes: sourceStats.dedup_lignes || 0,
                dedup_temps: sourceStats.dedup_temps || 0,
                verifier_lignes: sourceStats.verifier_lignes || 0,
                verifier_temps: sourceStats.verifier_temps || 0,
                // Ajouter les nouvelles statistiques
                ...additionalStats
            };

            // Créer l'entrée pour le fichier de destination
            registry[destFileName] = {
                ...fileInfo,
                size: fileInfo.size || this.getFileSize(destFileName),
                modified: fileInfo.modified || new Date().toISOString(),
                lastUpdated: new Date().toISOString(),
                statistiques: mergedStats
            };

            this.registryService.saveRegistry(registry);
            
            console.log(`📊 Statistiques transférées de ${sourceFileName} vers ${destFileName}:`);
            console.log(`   - Domain: ${mergedStats.domain_lignes} lignes (${mergedStats.domain_temps}s)`);
            console.log(`   - WHOIS: ${mergedStats.whois_lignes} lignes (${mergedStats.whois_temps}s)`);
            console.log(`   - Déduplication: ${mergedStats.dedup_lignes} lignes (${mergedStats.dedup_temps}s)`);
            console.log(`   - Verifier: ${mergedStats.verifier_lignes} lignes (${mergedStats.verifier_temps}s)`);
            
            return mergedStats;
        } catch (error) {
            console.error(`❌ Erreur lors du transfert des statistiques de ${sourceFileName} vers ${destFileName}:`, error.message);
            throw error;
        }
    }

    /**
     * Récupère la taille d'un fichier
     * @param {string} fileName - Nom du fichier
     * @returns {number} Taille en octets
     */
    getFileSize(fileName) {
        try {
            const filePath = path.join(this.dataDir, fileName);
            if (fs.existsSync(filePath)) {
                return fs.statSync(filePath).size;
            }
            return 0;
        } catch (error) {
            return 0;
        }
    }

    /**
     * Obtient les statistiques complètes d'un fichier
     * @param {string} fileName - Nom du fichier
     * @returns {Object} Statistiques complètes
     */
    getFileStats(fileName) {
        try {
            const registry = this.registryService.loadRegistry();
            return registry[fileName]?.statistiques || {};
        } catch (error) {
            console.warn(`⚠️ Erreur lors de la récupération des statistiques pour ${fileName}:`, error.message);
            return {};
        }
    }

    /**
     * Supprime les statistiques d'un fichier
     * @param {string} fileName - Nom du fichier
     */
    removeFileStats(fileName) {
        try {
            const registry = this.registryService.loadRegistry();
            if (registry[fileName]) {
                delete registry[fileName];
                this.registryService.saveRegistry(registry);
                console.log(`🗑️ Statistiques supprimées pour ${fileName}`);
            }
        } catch (error) {
            console.warn(`⚠️ Erreur lors de la suppression des statistiques pour ${fileName}:`, error.message);
        }
    }

    /**
     * Obtient un résumé des statistiques de tous les fichiers
     * @returns {Object} Résumé des statistiques
     */
    getAllStatsSummary() {
        try {
            const registry = this.registryService.loadRegistry();
            const summary = {
                totalFiles: 0,
                totalDomainLines: 0,
                totalWhoisLines: 0,
                totalDedupLines: 0,
                totalVerifierLines: 0,
                totalDomainTime: 0,
                totalWhoisTime: 0,
                totalDedupTime: 0,
                totalVerifierTime: 0
            };

            Object.values(registry).forEach(fileInfo => {
                if (fileInfo.statistiques) {
                    summary.totalFiles++;
                    summary.totalDomainLines += fileInfo.statistiques.domain_lignes || 0;
                    summary.totalWhoisLines += fileInfo.statistiques.whois_lignes || 0;
                    summary.totalDedupLines += fileInfo.statistiques.dedup_lignes || 0;
                    summary.totalVerifierLines += fileInfo.statistiques.verifier_lignes || 0;
                    summary.totalDomainTime += fileInfo.statistiques.domain_temps || 0;
                    summary.totalWhoisTime += fileInfo.statistiques.whois_temps || 0;
                    summary.totalDedupTime += fileInfo.statistiques.dedup_temps || 0;
                    summary.totalVerifierTime += fileInfo.statistiques.verifier_temps || 0;
                }
            });

            return summary;
        } catch (error) {
            console.warn('⚠️ Erreur lors du calcul du résumé des statistiques:', error.message);
            return {};
        }
    }
}

module.exports = StatisticsService;
